#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "led.h"
#include "sys.h"
#include "tim.h"
#include "oled.h"

int main(void)
{
	delay_init(168);
	TIM3_Init(15000,8400);
	Sec=0;
	OLED_Init();
	unsigned int Min=0,Hour=0;
	while(1)
	{
		OLED_ShowNum(1,1,Hour,2);
		OLED_ShowString(1,3,":");
		OLED_ShowNum(1,4,Min,2);
		OLED_ShowString(1,6,":");
		OLED_ShowNum(1,7,Sec,2);
		if(Sec>59)
		{
		Sec=0;
		Min++;
		if(Min>59)
		{
		Min=0;
		Hour++;
		if(Hour>23)
		Hour=0;
		}
		}
		
	}
}
