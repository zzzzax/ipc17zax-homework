#include "stm32f4xx.h"                  

void key_init(void);
